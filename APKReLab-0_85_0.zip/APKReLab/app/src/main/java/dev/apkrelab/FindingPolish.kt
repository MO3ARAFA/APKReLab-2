package dev.apkrelab

/**
 * 0.40.0: false-positive reduction, applied to the findings of ONE class at the end of SecurityScanner.scanSmali.
 *
 * Principles (nothing is deleted: a finding is only lowered and the reason is stored in Finding.adjusted):
 *  - findings in test classes (JUnit / androidTest / mocks) become INFO;
 *  - heuristic findings (method-level or informational guesses) inside known library code are lowered one level;
 *  - exact findings (exact API + constant argument traced, or a manifest flag) are never lowered by scope.
 * [confidenceOf] tells the reader how much to trust a finding (HIGH = exact signal, MEDIUM = heuristic, LOW = informational).
 */
object FindingPolish {

    private val lowTitleHints = listOf(
        "targetsdk", "accessibility", "fileprovider", "pinning", "detection", "qr/barcode", "logs requests",
        "integrity", "root ", "emulator", "keyboard cache", "high-entropy embedded string(s)"
    )
    private val mediumTitleHints = listOf(
        "possible", "may build", "straight from an intent", "dynamically built", "security-sounding",
        "intent redirection", "dynamic code loading", "shell command", "sensitive value", "near a credential",
        "hardware identifier", "fragment injection"
    )

    /** 0.66.4: TLS rules lowered one level when the class is library / obfuscated code, even though their confidence is HIGH. */
    val SCOPE_LOWERED_RULES: Set<String> = setOf("tls-trustmanager", "tls-hostname-verifier", "tls-insecure-socket-factory")

    fun confidenceOf(f: SecurityScanner.Finding): String {
        val t = f.title.lowercase()
        if (f.severity == SecurityScanner.Severity.INFO) return "LOW"
        if (f.confidence.isNotEmpty()) return f.confidence      // 0.41.0: set by the rule that produced the finding
        if (lowTitleHints.any { t.contains(it) }) return "LOW"
        if (mediumTitleHints.any { t.contains(it) }) return "MEDIUM"
        return "HIGH"
    }

    private fun lowered(s: SecurityScanner.Severity): SecurityScanner.Severity {
        val next = minOf(SecurityScanner.Severity.INFO.rank, s.rank + 1)
        return SecurityScanner.Severity.values().first { it.rank == next }
    }

    private fun isTestClass(type: String): Boolean =
        type.startsWith("Landroidx/test/") || type.startsWith("Lorg/junit/") || type.startsWith("Lorg/mockito/") ||
            type.startsWith("Lio/mockk/") || type.contains("/androidTest/") || type.endsWith("Test;") || type.endsWith("Tests;")

    /**
     * 0.42.0: manifest findings. The manifest describes the WHOLE app, so the class-level lowering (test class, heuristic inside a
     * library) never applies: nothing is lowered here. The pass only guarantees every finding carries a confidence (the rule's own
     * value; the title hints are the fallback) and can never throw.
     */
    fun applyManifest(list: List<SecurityScanner.Finding>): List<SecurityScanner.Finding> {
        for (f in list) {
            try {
                if (f.confidence.isEmpty()) f.confidence = confidenceOf(f)
            } catch (_: Throwable) { }
        }
        return list
    }

    /**
     * 0.43.0: resource findings (res/ XML, resources.arsc). Same contract as [applyManifest]: nothing is lowered (a resource is
     * not a class, so there is no test-class / library scope); every finding just carries a confidence.
     */
    fun applyResource(list: List<SecurityScanner.Finding>): List<SecurityScanner.Finding> = applyManifest(list)

    fun apply(list: List<SecurityScanner.Finding>, classType: String, appBound: Boolean = false): List<SecurityScanner.Finding> {
        val test = isTestClass(classType)
        for (f in list) {
            try {
                // 0.82.0: an obfuscated class tied to the app's own package is app code: scope APP, none of the OBF lowerings below
                if (appBound && f.scope == SecurityScanner.Scope.OBF) {
                    f.scope = SecurityScanner.Scope.APP
                    f.detail = f.detail + "  [Renamed by R8, but this is the app's own code: the class references the app's package.]"
                }
                if (f.severity == SecurityScanner.Severity.INFO) continue
                if (test) {
                    f.severity = SecurityScanner.Severity.INFO
                    f.adjusted = "Lowered to INFO: test class."
                } else if (f.ruleId in SCOPE_LOWERED_RULES && (f.scope == SecurityScanner.Scope.LIB || f.scope == SecurityScanner.Scope.OBF)) {
                    // 0.66.4: these rules are HIGH confidence about the CODE PATTERN, but the pattern in a third-party SDK (named
                    // library or R8-obfuscated) is not the app developer's decision and is often unused. Exness: a CRITICAL no-op
                    // TrustManager in obfuscated `r9e` stayed CRITICAL because the confidence is HIGH. One level down, reason stored.
                    f.severity = lowered(f.severity)
                    f.adjusted = "Lowered one level: " + (if (f.scope == SecurityScanner.Scope.LIB) "known library" else "obfuscated (likely third-party)") +
                        " code; the pattern is exact but usage / reachability from the app is not checked."
                } else if (f.scope == SecurityScanner.Scope.LIB && confidenceOf(f) != "HIGH") {
                    f.severity = lowered(f.severity)
                    f.adjusted = "Lowered one level: heuristic finding inside known library code."
                } else if (f.scope == SecurityScanner.Scope.OBF && confidenceOf(f) != "HIGH") {
                    // 0.46.0: obfuscated packages (a/b/c, mu.h) in a real APK are overwhelmingly third-party SDK code after R8;
                    // a heuristic (non-exact) finding there is noise for the app developer, so it is lowered like a library one.
                    // Exact findings (confidence HIGH: traced constant / exact API + argument) are kept, so e.g. an
                    // addJavascriptInterface in the app's obfuscated core code still surfaces at full severity.
                    f.severity = lowered(f.severity)
                    f.adjusted = "Lowered one level: heuristic finding inside obfuscated (likely third-party) code."
                }
            } catch (_: Throwable) { }
        }
        return list
    }

    /**
     * 0.49.5: rules whose risk depends on a caller (another app, a deep link, a crafted Intent) reaching the code. Only these are
     * traced beyond HIGH taint flows, and only these get the "not reached" note. Rules such as crypto, external storage or
     * Application-class code loading are NOT caller-driven: "no path from an exported component" says nothing about them.
     */
    val REACH_RULES: Set<String> = setOf(
        "taint-flow", "webview-file-access", "webview-js-interface", "webview-intent-url", "deeplink-config-poisoning",
        "deeplink-host-validation", "provider-openfile-segment", "intent-redirection", "implicit-intent-sensitive",
        "broadcast-unprotected-send", "shell-exec", "zip-slip", "sql-concat", "uri-grant-via-result", "pick-result-file",
        "log-credential-object", "storage-file-mode"
    )

    /**
     * 0.51.3: rules whose finding is intrinsic (the weakness exists whoever calls it), so a lone AI "false positive" is suspicious.
     * NOT here: `deserialization` (rule confidence HIGH, but NewPipe's in-memory byte[] round trip was a correct AI FP).
     */
    val GUARD_EXACT_RULES: Set<String> = setOf(
        "crypto-hardcoded-key", "crypto-static-iv", "res-strings-url-credentials", "dex-load-writable-dir", "package-context-code"
    )

    /**
     * 0.51.1: rules where "an exported component reaches it" makes an AI false positive suspicious (attacker-controlled input is the
     * point). shell-exec / sql-concat / zip-slip / log rules are NOT here: the benchmark run showed a correct AI "FP" on a constant
     * `which su` root check being turned into REVIEW only because the code was reachable.
     */
    val GUARD_REACH_RULES: Set<String> = setOf(
        "taint-flow", "webview-file-access", "webview-js-interface", "webview-intent-url", "deeplink-config-poisoning",
        "deeplink-host-validation", "provider-openfile-segment", "intent-redirection", "uri-grant-via-result", "pick-result-file"
    )

    /** 0.49.5: true if this finding should be traced by the call graph. Manifest findings (no class) never are. */
    fun wantsReach(f: SecurityScanner.Finding): Boolean {
        if (f.clsIndex < 0) return false
        if (f.ruleId == "taint-flow" && f.severity.rank <= 1) return true
        return f.ruleId in REACH_RULES && f.severity.rank <= 2 && f.scope == SecurityScanner.Scope.APP
    }

    /**
     * 0.49.1 / 0.49.3 / 0.49.5: annotation for findings that the call graph traced and could NOT reach from an exported
     * component. 0.49.1 lowered their severity; the OVAA benchmark showed that was wrong: the call graph follows method calls and
     * (since 0.49.4) explicit launches only, not implicit Intents, so a real flow can look "unreachable". The severity is left alone
     * and only a note is added. Nothing is lowered, nothing is dropped. Since 0.49.5 the note covers every traced finding of
     * [REACH_RULES], not only Intent-sourced taint flows.
     */
    fun applyReach(list: List<SecurityScanner.Finding>): List<SecurityScanner.Finding> {
        for (f in list) {
            try {
                if (f.reach != "NO" || f.adjusted.isNotEmpty() || f.ruleId !in REACH_RULES) continue
                if (f.ruleId == "taint-flow" && !f.detail.startsWith("Data from Intent.")) continue
                f.adjusted = "Not reached from an exported component by method calls or explicit startActivity(new Intent(ctx, X.class)) hops. It can still be reached through implicit Intents with a framework action (VIEW, SEND), string-built ComponentNames or PendingIntents " +
                    "(the call graph follows explicit launches and custom-action implicit Intents only): check who launches this component."
            } catch (_: Throwable) { }
        }
        return list
    }

    /**
     * 0.77.0 (Termux Play build: KeystoreAPI$2, reached only through TermuxService guarded by a SIGNATURE permission): a HIGH / CRITICAL
     * taint finding that the call graph could NOT reach from an exported component (reach == "NO") is lowered ONE level when its class is
     * not an Android component at all (a helper: implicit Intents cannot start it, only a component calling it, and those calls are what the
     * graph follows) or belongs to a component guarded by a signature-level permission (only same-signer apps can start it).
     * A component that is NOT a helper keeps its severity (0.49.1 lesson: OVAA WebViewActivity is reached through an implicit forward).
     * Returns the number lowered.
     */
    fun lowerUnreachedHelpers(list: List<SecurityScanner.Finding>, componentTypes: Set<String>, guardedTypes: Set<String>): Int {
        var n = 0
        for (f in list) {
            try {
                if (f.reach != "NO" || !f.ruleId.startsWith("taint") || f.severity.rank > 1) continue
                val t = f.classType ?: continue
                val outer = if (t.contains('$')) t.substringBefore('$') + ";" else t
                val component = t in componentTypes || outer in componentTypes
                val guarded = t in guardedTypes || outer in guardedTypes
                if (component && !guarded) continue
                f.severity = if (f.severity == SecurityScanner.Severity.CRITICAL) SecurityScanner.Severity.HIGH else SecurityScanner.Severity.MEDIUM
                f.confidence = "LOW"
                val why = if (guarded) "it belongs to a component protected by a signature-level permission (only apps signed with the same key can start it)"
                    else "its class is not an Android component (no other app can start it directly; only the app's components call it, and no exported one does)"
                f.adjusted = (if (f.adjusted.isNotEmpty()) f.adjusted + " " else "") + "Lowered one level: no exported component reaches it and $why."
                n++
            } catch (_: Throwable) { }
        }
        return n
    }

    /**
     * 0.80.0 (Infinity DownloadedMediaDeleteActionBroadcastReceiver): a HIGH / CRITICAL taint finding whose source is an Intent and whose
     * class (or outer class) is a broadcast RECEIVER or a SERVICE that the manifest does NOT export drops one level (confidence LOW): another
     * app cannot send to it directly, it is reached through the app's own PendingIntents / explicit Intents. Activities are left alone: a
     * non-exported activity is often reached through an exported one that forwards the caller's data (OVAA WebViewActivity, Infinity
     * LinkResolverActivity -> WebViewActivity). [internalTypes] = non-exported receiver / service types. Returns the number lowered.
     */
    fun lowerNonExportedReceivers(list: List<SecurityScanner.Finding>, internalTypes: Set<String>): Int {
        var n = 0
        for (f in list) {
            try {
                if (!f.ruleId.startsWith("taint") || f.severity.rank > 1 || !f.detail.startsWith("Data from Intent.")) continue
                val t = f.classType ?: continue
                val outer = if (t.contains('$')) t.substringBefore('$') + ";" else t
                if (t !in internalTypes && outer !in internalTypes) continue
                f.severity = if (f.severity == SecurityScanner.Severity.CRITICAL) SecurityScanner.Severity.HIGH else SecurityScanner.Severity.MEDIUM
                f.confidence = "LOW"
                f.adjusted = (if (f.adjusted.isNotEmpty()) f.adjusted + " " else "") +
                    "Lowered one level: the Intent is read in a receiver / service that the manifest does not export, so another app cannot send it directly (only through this app's own PendingIntents or explicit Intents)."
                n++
            } catch (_: Throwable) { }
        }
        return n
    }

    /**
     * 0.81.0: the cleartext configuration cards ("Cleartext (plain HTTP) traffic allowed", "Network Security Config: cleartext permitted")
     * are MEDIUM by default; they go back to HIGH when the app's own code uses a plain-HTTP URL ([CleartextUrlUsedRule] produced a card), which
     * is named in them. Returns the number raised.
     */
    fun applyNetworkEvidence(list: List<SecurityScanner.Finding>): Int {
        val use = list.firstOrNull { it.ruleId == "cleartext-url-used" } ?: return 0
        var n = 0
        for (f in list) {
            if (f.ruleId != "manifest-cleartext-traffic" && f.ruleId != "res-nsc-cleartext") continue
            if (f.severity != SecurityScanner.Severity.MEDIUM) continue
            f.severity = SecurityScanner.Severity.HIGH
            f.detail = f.detail + " Raised to HIGH: the app's own code uses a plain-HTTP URL (" + (use.classType ?: "?").removePrefix("L").removeSuffix(";").replace('/', '.') + ")."
            n++
        }
        return n
    }

    /**
     * 0.81.0 (AnkiDroid CardContentProvider): the manifest card "Exported provider without a permission: X" drops to LOW (confidence LOW)
     * when the provider class X produced a [ProviderCodePermissionRule] marker (every data method checks the caller in code).
     */
    fun applyProviderCodeChecks(list: List<SecurityScanner.Finding>): Int {
        val checked = list.filter { it.ruleId == "provider-code-permission" }.mapNotNull { it.classType }
            .map { it.removePrefix("L").removeSuffix(";").replace('/', '.') }.toSet()
        if (checked.isEmpty()) return 0
        var n = 0
        for (f in list) {
            if (f.ruleId != "manifest-exported-components" || !f.title.startsWith("Exported provider without a permission:")) continue
            val name = f.title.substringAfter(":").trim()
            if (checked.none { it == name || it.endsWith(name) || name.endsWith(it) }) continue
            if (f.severity == SecurityScanner.Severity.LOW && f.adjusted.contains("checks the calling app in code")) continue   // reachPass runs per report
            f.severity = SecurityScanner.Severity.LOW
            f.confidence = "LOW"
            f.adjusted = (if (f.adjusted.isNotEmpty()) f.adjusted + " " else "") +
                "Lowered: the manifest has no permission, but every data method of the provider checks the calling app in code (see the provider-code-permission note)."
            n++
        }
        return n
    }

    /**
     * 0.81.0 (AnkiDroid: ACRA's crash dialog, exported=false, in its own `:acra` process): a HIGH / CRITICAL taint finding whose Intent was
     * handed over by a NON-exported activity that runs in a SEPARATE process (the activity type appears in the finding's chain / via text)
     * drops one level: such a dialog is started by the app's own crash handler, not by another app. Narrow on purpose: non-exported activities
     * in the main process keep their severity (OVAA, Infinity: forwarded by exported ones). Returns the number lowered.
     */
    fun lowerSeparateProcessDialogs(list: List<SecurityScanner.Finding>, separateProcessActivities: Set<String>): Int {
        if (separateProcessActivities.isEmpty()) return 0
        var n = 0
        for (f in list) {
            if (!f.ruleId.startsWith("taint") || f.severity.rank > 1 || !f.detail.startsWith("Data from Intent.")) continue
            val hit = separateProcessActivities.firstOrNull { f.detail.contains(it) || f.classType == it } ?: continue
            f.severity = if (f.severity == SecurityScanner.Severity.CRITICAL) SecurityScanner.Severity.HIGH else SecurityScanner.Severity.MEDIUM
            f.confidence = "LOW"
            f.adjusted = (if (f.adjusted.isNotEmpty()) f.adjusted + " " else "") +
                "Lowered one level: the Intent belongs to " + hit.removePrefix("L").removeSuffix(";").replace('/', '.') + ", an activity that is not exported and runs in its own process (a crash / report dialog started by the app itself)."
            n++
        }
        return n
    }

    /** 0.81.0: smali types of NOT exported activities declared with their own android:process. */
    fun separateProcessActivities(mc: ManifestContext): Set<String> =
        mc.components.filter { !it.exported && it.tag == "activity" && it.headerAttrs.contains("android:process=") }
            .map { mc.smaliTypeOf(it) }.filter { it.isNotEmpty() }.toSet()

    /**
     * 0.84.0 (OpenTracks `CustomContentProvider`, exported=false): the text rules on provider code ([provider-sql-injection],
     * [provider-openfile-segment]) look at the class only. A provider the manifest does not export is reached only by the app itself or through
     * a URI it grants, so the finding drops one level (confidence LOW) and says why. Returns the number lowered.
     */
    fun lowerNonExportedProviders(list: List<SecurityScanner.Finding>, nonExportedProviders: Set<String>): Int {
        if (nonExportedProviders.isEmpty()) return 0
        var n = 0
        for (f in list) {
            try {
                if (f.ruleId != "provider-sql-injection" && f.ruleId != "provider-openfile-segment") continue
                if (f.adjusted.contains("not exported")) continue                      // reachPass runs per report: idempotent
                val t = f.classType ?: continue
                val outer = if (t.contains('$')) t.substringBefore('$') + ";" else t
                if (t !in nonExportedProviders && outer !in nonExportedProviders) continue
                f.severity = when (f.severity) {
                    SecurityScanner.Severity.CRITICAL -> SecurityScanner.Severity.HIGH
                    SecurityScanner.Severity.HIGH -> SecurityScanner.Severity.MEDIUM
                    SecurityScanner.Severity.MEDIUM -> SecurityScanner.Severity.LOW
                    else -> f.severity
                }
                f.confidence = "LOW"
                f.adjusted = (if (f.adjusted.isNotEmpty()) f.adjusted + " " else "") +
                    "Lowered one level: this provider is not exported by the manifest, so another app cannot call it directly (only this app, or a URI it grants with grantUriPermissions)."
                n++
            } catch (_: Throwable) { }
        }
        return n
    }

    /**
     * Smali types of the providers the manifest does NOT export. 0.84.0 (OpenTracks: the manifest declares `ShareContentProvider`, exported=false,
     * and the SQL text rule fires in its app-class BASE `CustomContentProvider`): the superclass chain of every declared provider counts too
     * ([superOf] gives the superclass of an app class, null at a framework class), minus every class that is also in the chain of an EXPORTED provider.
     */
    fun nonExportedProviders(mc: ManifestContext, superOf: (String) -> String? = { null }): Set<String> {
        fun chain(t: String): List<String> {
            val out = ArrayList<String>(); var c: String? = t; var n = 0
            while (c != null && n++ < 8) { out.add(c); c = superOf(c) }
            return out
        }
        val exported = mc.components.filter { it.exported && it.tag == "provider" }.map { mc.smaliTypeOf(it) }.filter { it.isNotEmpty() }.flatMap { chain(it) }.toSet()
        val internal = mc.components.filter { !it.exported && it.tag == "provider" }.map { mc.smaliTypeOf(it) }.filter { it.isNotEmpty() }.flatMap { chain(it) }.toSet()
        return internal - exported
    }

    /**
     * 0.85.0 (Quillpad): the 0.66.4 rule lowers a TLS finding in obfuscated code one level because such code is usually an unused third-party SDK
     * (Exness `r9e`). When the app really INSTALLS the class (a method instantiates it and calls `SSLContext.init`, see
     * [SecurityScanner.tlsInstalled]) it is in use and the finding goes back up one level. Run after the whole scan. Returns the number restored.
     */
    fun restoreInstalledTls(list: List<SecurityScanner.Finding>): Int {
        if (SecurityScanner.tlsInstalled.isEmpty()) return 0
        var n = 0
        for (f in list) {
            try {
                if (f.ruleId !in SCOPE_LOWERED_RULES || f.scope != SecurityScanner.Scope.OBF) continue
                if (!f.adjusted.startsWith("Lowered one level: obfuscated")) continue
                val t = f.classType ?: continue
                if (t !in SecurityScanner.tlsInstalled) continue
                f.severity = when (f.severity) {
                    SecurityScanner.Severity.HIGH -> SecurityScanner.Severity.CRITICAL
                    SecurityScanner.Severity.MEDIUM -> SecurityScanner.Severity.HIGH
                    SecurityScanner.Severity.LOW -> SecurityScanner.Severity.MEDIUM
                    else -> f.severity
                }
                f.adjusted = "Restored one level: an obfuscated class, but a method of this app instantiates it and installs it (SSLContext.init, a hostname-verifier / socket-factory setter), so it is in use."
                n++
            } catch (_: Throwable) { }
        }
        return n
    }

    /** 0.80.0: smali types of the receivers and services the manifest does NOT export. */
    fun nonExportedReceiversAndServices(mc: ManifestContext): Set<String> =
        mc.components.filter { !it.exported && (it.tag == "receiver" || it.tag == "service") }.map { mc.smaliTypeOf(it) }.filter { it.isNotEmpty() }.toSet()

    /**
     * 0.51.0: an AI "false positive" verdict is a second opinion, not a fact (the same InsecureBankv2 finding was FP in one run and TP
     * in the next). If the rule itself marked the finding HIGH confidence, or it is a caller-driven finding (REACH_RULES) that the call graph
     * reaches from an exported component (exact or approximate), the verdict becomes REVIEW and the AI's reason stays in the note.
     * Returns true when the verdict was changed.
     */
    fun guardFalsePositive(f: SecurityScanner.Finding): Boolean {
        if (f.verdict != "FP") return false
        val exact = f.confidence == "HIGH" && f.ruleId in GUARD_EXACT_RULES   // 0.51.3: only intrinsic weaknesses
        val reached = f.ruleId in GUARD_REACH_RULES && f.reach.startsWith("YES")
        if (!exact && !reached) return false
        // 0.51.2: a confident AI reason about what the code really does is kept (Aegis: `equals("offline")` flagged as indexOf host check,
        // AI 90% FP, was right). The guard is for the unsure / unstable verdicts and for exact rules.
        val conf = Regex("\\(confidence (\\d+)%\\)").find(f.verdictNote)?.groupValues?.get(1)?.toIntOrNull() ?: -1
        if (!exact && conf >= 85) return false
        f.verdict = "REVIEW"
        f.verdictNote = ("AI said false positive, but " + (if (exact) "an exact rule matched" else "an exported component reaches this code") +
            " (AI verdicts are not stable between runs): look at it yourself.\nAI reason: " + f.verdictNote).trim()
        return true
    }
}
