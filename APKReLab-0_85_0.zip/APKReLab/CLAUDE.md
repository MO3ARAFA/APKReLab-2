# CLAUDE.md - APK ReLab (read this first, then HANDOFF.md and BLUEPRINT.md)

On-device Android SAST app (Kotlin + a Java `ir` package: Dalvik -> IR -> SSA -> call graph -> inter-procedural taint). Owner: an Arabic speaker (Egyptian), builds on a PHONE with Code On the Go; wants short, actionable answers, in Egyptian Arabic when chatting. Code, comments and docs stay in English.

## How the owner works with you
- You produce a versioned zip (APKReLab-0_NN_0.zip) or a git commit; the owner builds it on the phone and sends back errors / screenshots / scan reports (markdown). Gradle is NOT run by you today (see "Build" below).
- Constraint of the product: it runs on Android ART with a 256-512 MB heap. Anything that holds the whole app's IR in memory, or grows per class, is a bug. Big apps are analysed in groups (ScopePlanner / SsaGroups).

## Non-negotiable working rules (they exist because each one caught a real mistake)
1. **Measure before you build, and say what you did not measure.** A claim is "verified" only if you ran it. `MainActivity.kt` and the Android-only files (Ui.kt, Ai*.kt, Council.kt ... anything importing android/androidx) were NEVER compiled by the previous assistant (no SDK in its sandbox); say so for every change you make there until you have built it.
2. **Held-out discipline.** The first run of a benchmark app is FROZEN in tools/benchmark/runs/ before any change. A fix made because of an app moves that app to the tuning set. Never report a benchmark number on an app you tuned on as if it were blind. Only Sieve is still held-out; the real-app sets 1-6 are tuning sets now. Next blind set = set 7 (protocol: tools/benchmark/heldout_real/PROTOCOL*.md).
3. **Precision = read the smali.** For real apps there is no expected list: read EVERY HIGH/CRITICAL card in the decoded smali/manifest and judge TP / TP-1CLICK / TP-low / BY-DESIGN / FP. Report by card AND by distinct issue. Do not "improve" a number by re-running.
4. **No tuning to names.** No package-name lists, no per-app exceptions (a proposal to lower network cards by "jellyfin / nextcloud" names was rejected). Prefer evidence in the code.
5. **Every new rule gets a negative twin test** and, for engine changes, a mutation check (turn the feature off, the positive test must fail).
6. **Tell the truth about provenance.** If something is already in the tree and you did not write it, say so (this happened twice: the MD5 hash-helper rule in 0.74.0 and the first half of 0.82.0).
7. **Do not delete or rewrite files to tidy up**; keep HANDOFF.md (it is the log) and add to it. Memory-bank style files other than HANDOFF/BLUEPRINT do not exist.
8. The owner's own product (JustMarkets) was read with its APK: "0 HIGH" was honest for 6.15.1. It is a tuning app.

## Build and test (what exists, what does not)
- `app/build.gradle.kts`: AGP 9.3.1, Kotlin 2.3.21 (+ Compose compiler plugin), compileSdk/targetSdk 36, minSdk 26, JDK 17 target. Dependencies: ARSCLib, smali / baksmali 3.0.9, apksig, jadx-core 1.5.0 (optional), JUnit 4.13.2 and org.json for unit tests.
- **There is NO Gradle wrapper in the repo** (the owner builds in Code On the Go, which brings its own Gradle). On a PC you must create one and pick a Gradle version that AGP 9.3.1 supports (look it up in the AGP release notes; the previous assistant did not verify this). Needs an Android SDK with platform 36.
- JVM unit tests: `./gradlew testDebugUnitTest` (tests live in app/src/test; the `ir` ones are plain Java).
- The previous assistant ran the tests WITHOUT Gradle: a JUnit stub + kotlinc 2.3.21 + android stubs (tools/sandbox/README.md and tools/sandbox/SETUP_FROM_SCRATCH.md). Last results (0.82.0): `ir` 268/268, Kotlin (non-Android classes only) 126/126. With a real SDK you can compile everything: do that FIRST and fix whatever the Android-only files break.

## Where things are
- `app/src/main/java/dev/apkrelab/` Kotlin: SecurityScanner.kt (scope, secrets, dedupe/absorb), ScanRules*.kt (rules: Legacy = old text rules, Ir = rules on the IR, Manifest, Resources, FinTech, Ovaa, Taint), FindingPolish.kt (severity lowering, reach), MainActivity.kt (UI, scan orchestration, ssaFindings, reachPass, AI triage), Council.kt (AI second opinion), Capabilities.kt.
- `.../ir/` Java: SmaliParser, Cfg, SsaForm, CallGraph, TaintIr (the engine), SsaBridge (flows -> cards), ScopePlanner + SsaGroups (big apps), IrRules (rules on one class).
- `tools/sandbox/` measurement harnesses (SandboxScan.kt = the real Kotlin pipeline without the UI, MeasureBig / MeasureCompare / FlowDump = SSA only). `tools/benchmark/` bench.py, expected lists, runs/ (frozen reports), heldout_real/ (protocols + judgements).
